<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '?s(>??:>&2xFLvL~Gegp[?t&H#hJVC:*S~UN-U<kS1HS}T9xoow>E6-t[88a5U4b' );
define( 'SECURE_AUTH_KEY',   'P3gA7RL+HIf BBxiTkx$s/fvNf{xRM5b8^%}K44_r]>p!UkQ7kx5931/xinT_$3+' );
define( 'LOGGED_IN_KEY',     'vM?}Kzm-h}i^fZ%b}Yj1mQ_!{xd0P/+9qV>$nh=|:&y!KY<9>FmnEuU3+J5^GWWw' );
define( 'NONCE_KEY',         '%^g(WDK?B/O-u$B]2QFWy[vG;cv*; tj*}Dp&Jo-a>GigsBDxrjT:zBFV^yjxh?H' );
define( 'AUTH_SALT',         'w?[uz?RB]H@m[Bt_YBfC[8|vpIEGxggos23d9[*/-}OdY)_`QC;&_?G^fuFQXs<u' );
define( 'SECURE_AUTH_SALT',  'JL8d9u*.h#!)pV,,:^+x{^HD1x4klmK0,%Qx4iVt}E3%0AS4HLo*`C.H:.>qhqCW' );
define( 'LOGGED_IN_SALT',    'McTwr?I^O8Mx&Dd_pywvL%IzS;29w&0,YlKGegpTA)ZO:~,r$/=wB~b~?,x[.W4a' );
define( 'NONCE_SALT',        '_x$e<Uarp(CD28,D&ge8Y&)*p3Ve<!>D[8Si&<5Bx!^6,5!gywG, 2FW>!TJKk^U' );
define( 'WP_CACHE_KEY_SALT', 'Ij*c#w?WHFF46Q;Kv(IyQ@P_9W+[U,oWYZm4~p&~a}ozRp7}TF.1#4`&id_J1n+6' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
